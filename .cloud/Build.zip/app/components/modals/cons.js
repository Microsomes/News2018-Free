module.exports={
    data(){
        return {

        }
    },
    template:
    `
    <Page class="page">  
    
    <ActionBar flat="true" title="Coming this Friday">
     </ActionBar>
 
    <StackLayout height="100%">
    <Image src="https://firebasestorage.googleapis.com/v0/b/social-station-69cfc.appspot.com/o/web%2Fimages%2Fconspiracies.jpg?alt=media&token=68a790c5-c9ae-4f6b-b5e6-db21d97f8657"></Image>
    <Label style="text-align:center" textWrap="true" style="font-size:30px;font-weight:bold;padding:10px;" text="Conpiracies coming this friday 13/07/2018 @ 5pm" />
      


    </StackLayout>
    
  </Page>



    `
}