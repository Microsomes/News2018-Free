module.exports={
    data(){
        return {

        }
    },
    template:
    `
    <Page class="page">
 
    <StackLayout>

    <Label class="login_text" text="Currently unavailable" />
      
    </StackLayout>
    
  </Page>
  `
}