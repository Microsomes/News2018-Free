module.exports={
    data(){
        return {

        }
    },
    template:
    `
    <Page class="page">  
    
    <ActionBar flat="true" title="Reading...">
     </ActionBar>
 
    <StackLayout>

    <Label text="Dashboard" />
      
    </StackLayout>
    
  </Page>



    `
}